# A simple firebase site example

![Firebase realtime data](http://a43d55f6a02c4be185ce-9cfa4cf7c673a59966ad8296f4c88804.r44.cf3.rackcdn.com/Firebase/firebase-logo.png)

If you'd like to learn more about getting started with Firebase. I recommend heading over to my blog at [deanhume.com](http://deanhume.com/Home/BlogPost/a-basic-guide-to-firebase-for-the-web/10142).
